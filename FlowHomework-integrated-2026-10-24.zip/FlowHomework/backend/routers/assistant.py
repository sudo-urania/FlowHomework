from datetime import date
import json
from typing import Any

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from config import MAX_DOCUMENT_CHARS, MAX_UPLOAD_BYTES, OPENAI_API_KEY
from services.ai_service import (
    answer_assignment_question,
    answer_student,
    plan_assignment_work,
)
from services.document_parser import extract_text

router = APIRouter(prefix="/assistant", tags=["assistant"])


class AssistantChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    today: date
    timezone: str = Field(default="local", max_length=80)
    assignments: list[dict[str, Any]] = Field(default_factory=list, max_length=300)
    availability: list[dict[str, Any]] = Field(default_factory=list, max_length=100)
    settings: dict[str, Any] = Field(default_factory=dict)


class AssistantChatResponse(BaseModel):
    answer: str


class AssignmentQuestionRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    assignment: dict[str, Any]
    instructionsText: str = Field(default="", max_length=MAX_DOCUMENT_CHARS)
    plan: dict[str, Any] = Field(default_factory=dict)
    history: list[dict[str, str]] = Field(default_factory=list, max_length=8)


class AssignmentQuestionResponse(BaseModel):
    answer: str


class AssignmentWorkPlanResponse(BaseModel):
    overview: str
    sections: list[dict[str, Any]]
    notes: list[str] = Field(default_factory=list)
    instructionsText: str
    sourceFiles: list[str]
    aiEnabled: bool


@router.post("/chat", response_model=AssistantChatResponse)
def chat(request: AssistantChatRequest):
    context = {
        "today": request.today.isoformat(),
        "timezone": request.timezone,
        "assignments": request.assignments,
        "unavailable_blocks": request.availability,
        "study_settings": request.settings,
    }
    try:
        return AssistantChatResponse(answer=answer_student(request.question, context))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        # Keep provider errors useful without exposing credentials or request internals.
        raise HTTPException(status_code=502, detail=f"OpenAI assistant request failed: {type(exc).__name__}") from exc


@router.post("/assignment/analyze", response_model=AssignmentWorkPlanResponse)
async def analyze_assignment_files(
    files: list[UploadFile] = File(...),
    assignment: str = Form(...),
):
    if not files or len(files) > 5:
        raise HTTPException(status_code=400, detail="Upload between one and five assignment files.")
    try:
        task = json.loads(assignment)
        if not isinstance(task, dict) or not str(task.get("title", "")).strip():
            raise ValueError("Assignment title is required.")
    except (json.JSONDecodeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=f"Invalid assignment details: {exc}") from exc

    total_bytes = 0
    chunks = []
    names = []
    for uploaded in files:
        name = uploaded.filename or "assignment-instructions.txt"
        raw = await uploaded.read(MAX_UPLOAD_BYTES - total_bytes + 1)
        total_bytes += len(raw)
        if total_bytes > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail=f"Combined upload is too large. Maximum is {MAX_UPLOAD_BYTES // (1024*1024)} MB.")
        text = extract_text(raw, name)
        names.append(name)
        chunks.append(f"--- {name} ---\n{text}")

    instructions = "\n\n".join(chunks)[:MAX_DOCUMENT_CHARS]
    try:
        plan, ai_enabled = plan_assignment_work(task, instructions)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not analyze the assignment: {type(exc).__name__}") from exc
    notes = list(plan.notes)
    if not ai_enabled:
        notes.insert(0, "OpenAI is not configured. This is a local starter breakdown; add OPENAI_API_KEY for instruction-aware AI analysis.")
    return AssignmentWorkPlanResponse(
        overview=plan.overview,
        sections=[section.model_dump() for section in plan.sections],
        notes=notes,
        instructionsText=instructions,
        sourceFiles=names,
        aiEnabled=ai_enabled and bool(OPENAI_API_KEY),
    )


@router.post("/assignment/ask", response_model=AssignmentQuestionResponse)
def ask_about_assignment(request: AssignmentQuestionRequest):
    try:
        answer = answer_assignment_question(
            request.question, request.assignment, request.instructionsText,
            request.plan, request.history,
        )
        return AssignmentQuestionResponse(answer=answer)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Assignment help request failed: {type(exc).__name__}") from exc
