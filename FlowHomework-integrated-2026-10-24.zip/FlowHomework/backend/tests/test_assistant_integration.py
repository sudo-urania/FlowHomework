from types import SimpleNamespace
from pathlib import Path
from fastapi.testclient import TestClient
from main import app
import services.ai_service as ai


def fake_client(calls):
    def parse(**kw):
        calls.append(kw)
        schema=kw['text_format']
        if schema is ai.AssignmentExtraction:
            return SimpleNamespace(output_parsed=ai.AssignmentExtraction(assignments=[ai.ExtractedAssignment(course_name='IST 196',title='Lab 1',instructions='Build and test a small app.',assignment_type='lab',due_date='2026-10-30',weight_percent=None,source_quote='Lab 1 due 2026-10-30',confidence=.9)]))
        if schema is ai.AssignmentAnalysis:
            return SimpleNamespace(output_parsed=ai.AssignmentAnalysis(difficulty=2,estimated_minutes=60,subtasks=[ai.ExtractedSubtask(title='Read and plan',estimated_minutes=20),ai.ExtractedSubtask(title='Build and verify',estimated_minutes=40)]))
        return SimpleNamespace(output_parsed=ai.AssignmentWorkPlan(overview='Plan grounded in the uploaded brief.',sections=[ai.WorkSection(title='Read requirements',description='List required inputs.',estimatedMinutes=20),ai.WorkSection(title='Build the app',description='Implement the stated behavior.',estimatedMinutes=30),ai.WorkSection(title='Test and submit',description='Verify expected output.',estimatedMinutes=10)],notes=[]))
    def create(**kw):
        calls.append(kw);return SimpleNamespace(output_text='Review the input validation requirement first.')
    return SimpleNamespace(responses=SimpleNamespace(parse=parse,create=create))


def test_mocked_openai_end_to_end(monkeypatch):
    import config, routers.assistant as assistant
    calls=[]
    monkeypatch.setattr(ai,'OPENAI_API_KEY','test-only')
    monkeypatch.setattr(config,'OPENAI_API_KEY','test-only')
    monkeypatch.setattr(assistant,'OPENAI_API_KEY','test-only')
    monkeypatch.setattr(ai,'_client',lambda:fake_client(calls))
    client=TestClient(app)
    upload=client.post('/syllabus/upload',files={'file':('sample.txt',b'Course: IST 196\nLab 1 due 2026-10-30','text/plain')})
    assert upload.status_code==200,upload.text
    assert upload.json()['aiEnabled'] is True
    assert upload.json()['assignments'][0]['estimatedMinutes']==60
    work=client.post('/assistant/assignment/analyze',data={'assignment':'{"id":"stable-id","title":"Lab 1"}'},files=[('files',('brief.txt',b'Validate input and submit source code.','text/plain'))])
    assert work.status_code==200,work.text
    assert work.json()['aiEnabled'] is True
    assert len(work.json()['sections'])==3
    answer=client.post('/assistant/assignment/ask',json={'question':'Where do I start?','assignment':{'title':'Lab 1'},'instructionsText':'Validate input.'})
    assert answer.status_code==200
    chat=client.post('/assistant/chat',json={'question':'Help me plan','today':'2026-10-24','assignments':[]})
    assert chat.status_code==200
    assert len(calls)==5
    assert all(call.get('store') is False for call in calls)


def test_missing_key_is_explicit_and_bad_files_rejected(monkeypatch):
    monkeypatch.setattr(ai,'OPENAI_API_KEY','')
    client=TestClient(app)
    response=client.post('/assistant/chat',json={'question':'Help','today':'2026-10-24'})
    assert response.status_code==503
    assert 'OPENAI_API_KEY' in response.json()['detail']
    bad=client.post('/assistant/assignment/analyze',data={'assignment':'{"title":"Lab"}'},files=[('files',('bad.exe',b'not a document'))])
    assert bad.status_code==415
