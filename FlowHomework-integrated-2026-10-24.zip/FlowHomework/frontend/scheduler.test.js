// Run with Node.js: node --test scheduler.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const context = { window: {}, Date, Math };
vm.createContext(context);
vm.runInContext(fs.readFileSync('./scheduler.js', 'utf8'), context);
const Scheduler = context.window.Scheduler;

test('split returns multiple subtasks for a large assignment with a due date', () => {
  const now = new Date('2026-10-24T08:00:00');
  const cfg = { sleep:'23:00', wake:'07:00', session:50, maxHours:4, blocks:[], exam:'2026-11-20T23:59' };
  const result = Scheduler.split(cfg, {title:'Research Project', due:'2026-11-20', min:360}, now);
  assert.ok(result.parts.length >= 3);
  assert.ok(result.parts.every(p => p.label && p.min > 0));
});

test('split reports when no sessions are available before deadline', () => {
  const now = new Date('2026-10-24T08:00:00');
  const cfg = { sleep:'23:00', wake:'07:00', session:50, maxHours:4, blocks:[] };
  const result = Scheduler.split(cfg, {title:'Project', due:'2026-10-23', min:180}, now);
  assert.equal(result.parts.length, 0);
  assert.ok(result.note);
});

test('work sections conserve workload, never overlap, and respect busy intervals', () => {
 const now=new Date('2026-10-24T08:00:00');
 const busyStart=new Date('2026-10-24T09:00:00'),busyEnd=new Date('2026-10-24T17:00:00');
 const cfg={sleep:'23:00',wake:'07:00',session:50,maxHours:4,blocks:[],isBusy:(a,b)=>a<busyEnd&&b>busyStart};
 const result=Scheduler.planWorkSections(cfg,{due:'2026-10-28'},[{id:'one',title:'Project',estimatedMinutes:360}],now);
 assert.equal(result.parts.reduce((n,p)=>n+p.min,0),360);
 for(const part of result.parts) assert(!(new Date(part.start)<busyEnd&&new Date(part.end)>busyStart));
 const ordered=result.parts.slice().sort((a,b)=>new Date(a.start)-new Date(b.start));
 for(let i=1;i<ordered.length;i++)assert(new Date(ordered[i-1].end)<=new Date(ordered[i].start));
});

test('insufficient capacity reports work instead of silently shrinking it', () => {
 const cfg={sleep:'23:00',wake:'07:00',session:50,maxHours:1,blocks:[]};
 const result=Scheduler.planWorkSections(cfg,{due:'2026-10-24'},[{title:'Project',estimatedMinutes:360}],new Date('2026-10-24T08:00:00'));
 assert(result.note.includes('310 minutes'));
 assert.equal(result.parts.reduce((n,p)=>n+p.min,0),50);
});
