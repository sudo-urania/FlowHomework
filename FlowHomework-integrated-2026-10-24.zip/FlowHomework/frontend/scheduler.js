/* FlowHomework scheduling rules. Pure functions, no DOM, so they can move to the backend later. */
(function () {
  const hm = s => { const [h, m] = s.split(':'); return +h * 60 + +m; };
  const MIN = 6e4;

  // Is this moment inside sleep time? (30 min buffer each side)
  function asleep(d, c) {
    const m = d.getHours() * 60 + d.getMinutes();
    const a = (hm(c.sleep) - 30 + 1440) % 1440, b = (hm(c.wake) + 30) % 1440;
    return a > b ? (m >= a || m < b) : (m >= a && m < b);
  }
  // Is this moment inside a weekly blocked time (work, classes...)?
  function blocked(d, c) {
    const m = d.getHours() * 60 + d.getMinutes();
    return (c.blocks || []).some(b => b.days.includes(d.getDay()) &&
      (hm(b.from) < hm(b.to) ? m >= hm(b.from) && m < hm(b.to) : m >= hm(b.from) || m < hm(b.to)));
  }
  const off = (d, c) => asleep(d, c) || blocked(d, c);
  const dayKey = (d, c) => new Date(d - hm(c.wake) * MIN).toDateString();

  // Build free study slots from now until 1 hour before the exam.
  function slots(c, now) {
    const end = new Date(new Date(c.exam) - 60 * MIN), L = +c.session;
    const brk = L >= 90 ? 15 : L >= 50 ? 10 : 5, out = [], perDay = {};
    let t = new Date(now), n = 0, guard = 0;
    t.setSeconds(0, 0); t.setMinutes(Math.ceil(t.getMinutes() / 5) * 5);
    while (t < end && guard++ < 20000) {
      if (off(t, c)) { t = new Date(+t + 5 * MIN); continue; }
      const k = dayKey(t, c); perDay[k] = perDay[k] || 0;
      if (perDay[k] + L > c.maxHours * 60) { t = new Date(+t + 15 * MIN); continue; }
      const fin = new Date(+t + L * MIN);
      let ok = fin <= end && (!c.isBusy || !c.isBusy(t,fin));
      for (let z = 5; ok && z <= L; z += 5) if (off(new Date(+t + z * MIN), c)) ok = false;
      if (!ok) { t = new Date(+t + 5 * MIN); continue; }
      out.push({ start: new Date(t), end: fin, items: [] });
      perDay[k] += L; n++;
      t = new Date(+fin + (n % 3 === 0 ? 30 : brk) * MIN); // longer rest every 3rd session
    }
    return out;
  }

  // subjects: [{id, name, topics:[{id, name, minutes, spent}]}] (only topics still to study)
  function plan(c, subjects, now = new Date()) {
    const sl = slots(c, now);
    const q = [];
    subjects.forEach(s => s.topics.forEach(t =>
      q.push({ id: t.id, sid: s.id, label: t.name, subject: s.name, min: Math.max(3, t.minutes - (t.spent || 0)) })));
    if (!sl.length) return { sessions: [], note: 'There is no study time left before the exam.' };

    const cap = sl.length * c.session, need = q.reduce((s, x) => s + x.min, 0);
    const scale = need > cap ? Math.max(0.35, cap / need) : 1;   // shrink reading if time is short
    q.forEach(x => { x.left = Math.max(3, x.min * scale); });

    let i = 0, si = 0, free = +c.session;
    while (i < q.length && si < sl.length) {
      const it = q[i], take = Math.min(it.left, free);
      it.left -= take; free -= take;
      if (take >= 3) sl[si].items.push({ id: it.id, sid: it.sid, label: it.label, subject: it.subject, min: Math.round(take), last: it.left <= 0.5 });
      if (it.left <= 0.5) i++;
      if (free < 3) { si++; free = +c.session; }
    }
    return {
      sessions: sl.filter(s => s.items.length),
      note: scale < 1 ? 'Not enough time to cover everything calmly, so each topic was shortened to ' + Math.round(scale * 100) + '%.' : ''
    };
  }

  // Break one assignment into work sessions on different days, before its due date.
  // Rule-based for now: the backend AI can later write smarter steps for each assignment.
  const TPL = {
    write: ['Understand the prompt and outline', 'Research and take notes', 'Draft the first half', 'Draft the second half', 'Revise and polish', 'Proofread and submit'],
    slides: ['Outline the story', 'Gather content and visuals', 'Build the first slides', 'Build the rest', 'Rehearse and polish', 'Final check and submit'],
    study: ['List the topics to cover', 'Review the first topics', 'Review the next topics', 'Practice questions', 'Fix weak spots', 'Final quick review'],
    gen: ['Read the brief and plan', 'Gather what you need', 'Work on the first part', 'Work on the second part', 'Review and improve', 'Final check and submit']
  };
  function split(c,task,now=new Date(),taken=[],skip=0){
    const total=Math.max(0,Math.round(Number(task.min)||0));
    if(!total) return {parts:[],note:'No remaining work.'};
    const count=Math.min(6,Math.max(1,Math.ceil(total/c.session)));
    const sections=Array.from({length:count},(_,i)=>({title:'Work on '+task.title+' ('+(i+1)+'/'+count+')',estimatedMinutes:Math.floor(total/count)+(i<total%count?1:0)}));
    return planWorkSections(c,task,sections,now,taken);
  }

  // Place instruction-derived work sections on separate available study days.
  // Session times, daily limits, blocked periods, deadlines, and other tasks are
  // enforced by the same slot generator used by the main planner.
  function planWorkSections(c, task, sections, now = new Date(), taken = []) {
    if (!task.due) return { parts: [], note: 'Add a due date before scheduling work sections.' };
    const all = slots({ ...c, exam: task.due + 'T23:59' }, now)
      .filter(s => !taken.some(t => s.start < t.end && s.end > t.start));
    if (!all.length) return { parts: [], note: 'There is no available study time before this due date.' };

    const dateKey = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const byDay = new Map();
    all.forEach(slot => {
      const key = dateKey(slot.start);
      if (!byDay.has(key)) byDay.set(key, []);
      byDay.get(key).push(slot);
    });
    const dayLoad = Object.fromEntries([...byDay.keys()].map(key => [key, 0]));
    const parts = [];
    let unscheduled = 0;

    sections.forEach(section => {
      let left = Math.max(1, Number(section.estimatedMinutes || 30));
      let partNo = 0;
      while (left > 0) {
        const day = [...byDay.keys()].filter(key => byDay.get(key).length)
          .sort((a, b) => dayLoad[a] - dayLoad[b] || a.localeCompare(b))[0];
        if (!day) { unscheduled += left; break; }
        const slot = byDay.get(day).shift();
        const minutes = Math.min(left, Number(c.session));
        const start = slot.start, end = new Date(+start + minutes * MIN);
        parts.push({ sectionId: section.id, sectionTitle: section.title,
          label: partNo ? section.title + ' (continued)' : section.title,
          start: start.toISOString(), end: end.toISOString(), min: minutes, done: false });
        dayLoad[day] += minutes;
        left -= minutes;
        partNo++;
      }
    });
    return { parts, note: unscheduled ? `${unscheduled} minutes could not fit before the deadline. Add more study time or adjust the estimates.` : '' };
  }

  window.Scheduler = { plan, split, planWorkSections };
})();
