(() => {
  const $ = s => document.querySelector(s), uid = () => Math.random().toString(36).slice(2, 9);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const nice = s => new Date(s + 'T00:00').toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); setTimeout(() => t.classList.remove('on'), 2600); };
  const store = (k, v) => v === undefined ? JSON.parse(localStorage.getItem(k) || 'null') : localStorage.setItem(k, JSON.stringify(v));
 
  /* ---------- auth (front-end placeholder: real auth must be done by the backend) ---------- */
  let mode = 'in', me = null, D = null, view = 'home', cur = new Date(); cur.setDate(1);
  const sha = async s => crypto.subtle
    ? [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map(b => b.toString(16).padStart(2, '0')).join('')
    : btoa(s);
  const setMode = m => {
    mode = m; $('#name-row').hidden = m === 'in'; $('#auth-err').textContent = '';
    $('#auth-sub').textContent = m === 'in' ? 'Welcome back. Sign in to continue.' : 'Create your account to get started.';
    $('#auth-go').textContent = m === 'in' ? 'Sign in' : 'Create account';
    $('#auth-switch').textContent = m === 'in' ? 'New here? Create an account' : 'Already have an account? Sign in';
  };
  $('#auth-switch').onclick = () => setMode(mode === 'in' ? 'up' : 'in');
  $('#auth-form').onsubmit = async e => {
    e.preventDefault(); const f = e.target.elements, email = f.email.value.trim().toLowerCase(), h = await sha(f.pw.value), U = store('sf-users') || {};
    if (mode === 'up') { if (U[email]) return $('#auth-err').textContent = 'That email already has an account.'; U[email] = { name: f.name.value.trim() || email.split('@')[0], h }; store('sf-users', U); }
    else if (!U[email] || U[email].h !== h) return $('#auth-err').textContent = 'Email or password is not right.';
    store('sf-session', email); e.target.reset(); boot();
  };
  $('#out').onclick = () => { localStorage.removeItem('sf-session'); boot(); };
 
  /* ---------- data: terms, and everything inside each term ---------- */
  const save = () => store('sf-data-' + me, D);
  const T = () => D.by[D.term];
  const blank = () => ({ courses: [], tasks: [], events: [], syllabi: [] });
  function load() {
    D = store('sf-data-' + me);
    if (!D) { const id = uid(), y = new Date().getFullYear(); D = { terms: [{ id, name: 'Term 1 · ' + y }], term: id, by: { [id]: blank() } }; save(); }
  }
  const cIdx = id => Math.max(0, T().courses.findIndex(c => c.id === id)) % 6 + 1;
  const cName = id => (T().courses.find(c => c.id === id) || {}).name || 'General';
  function course(name) {
    name = (name || '').trim() || 'General'; let c = T().courses.find(x => x.name.toLowerCase() === name.toLowerCase());
    if (!c) { c = { id: uid(), name }; T().courses.push(c); } return c;
  }
 
  function renderTerms() {
    $('#term').innerHTML = D.terms.map(t => '<option value="' + t.id + '"' + (t.id === D.term ? ' selected' : '') + '>' + esc(t.name) + '</option>').join('') + '<option value="__new">＋ New term…</option>';
  }
  $('#term').onchange = e => {
    if (e.target.value === '__new') {
      const n = (prompt('Name of the new term (e.g. Spring 2027)') || '').trim();
      if (n) { const id = uid(); D.terms.push({ id, name: n }); D.by[id] = blank(); D.term = id; }
    } else D.term = e.target.value;
    save(); render();
  };
 
  /* ---------- navigation ---------- */
  function go(v) {
    view = v; ['home', 'cal', 'tasks'].forEach(x => $('#v-' + x).hidden = x !== v);
    document.querySelectorAll('.nav').forEach(b => b.classList.toggle('on', b.dataset.view === v)); render();
  }
  document.querySelectorAll('.nav').forEach(b => b.onclick = () => go(b.dataset.view));
 
  /* ---------- Home: chat (rules-based stand-in for the future AI backend) ---------- */
  const say = (t, who) => { const l = $('#log'); l.insertAdjacentHTML('beforeend', '<div class="msg ' + (who || '') + '">' + esc(t) + '</div>'); l.scrollTop = l.scrollHeight; };
  function bot(q) {
    const t = T(), open = t.tasks.filter(k => !k.done), s = q.toLowerCase();
    if (/plan|study|schedule|adjust|move|resched/.test(s)) {
      if (!open.length) return 'Add a few tasks first, or upload a syllabus, and I will build a plan around them.';
      const last = open.map(k => k.due).filter(Boolean).sort().pop() || iso(new Date(Date.now() + 7 * 864e5));
      const subs = t.courses.map(c => ({ id: c.id, name: c.name, topics: open.filter(k => k.course === c.id).map(k => ({ id: k.id, name: k.title, minutes: Math.max(5, Math.round(k.min * (1 - k.progress / 100))) })) })).filter(x => x.topics.length);
      const P = Scheduler.plan({ exam: last + 'T23:00', sleep: '23:00', wake: '07:00', session: 50, maxHours: 4 }, subs);
      if (!P.sessions.length) return P.note || 'There is no free time before your last deadline. Try moving a due date.';
      const f = d => d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
      return 'Here are your next study sessions:\n' + P.sessions.slice(0, 4).map(x => '• ' + nice(iso(x.start)) + ' ' + f(x.start) + '–' + f(x.end) + ': ' + x.items.map(i => i.label).join(', ')).join('\n') + (P.note ? '\n' + P.note : '');
    }
    if (/due|week|soon|upcoming|homework|task/.test(s))
      return open.length ? 'Coming up:\n' + open.sort((a, b) => (a.due || '9') < (b.due || '9') ? -1 : 1).slice(0, 5).map(k => '• ' + k.title + ' (' + cName(k.course) + ')' + (k.due ? ' · ' + nice(k.due) : '')).join('\n') : 'Nothing pending. Enjoy the break!';
    return 'I can build a study plan, list what is due soon, or re-plan your schedule. Try one of the buttons below.';
  }
  $('#chips').innerHTML = ['Make me a study plan', 'What is due soon?', 'Adjust my schedule'].map(x => '<button type="button">' + x + '</button>').join('');
  const ask = q => { say(q, 'me'); say(bot(q)); };
  $('#chips').onclick = e => { if (e.target.tagName === 'BUTTON') ask(e.target.textContent); };
  $('#chat-form').onsubmit = e => { e.preventDefault(); const m = $('#msg').value.trim(); if (m) { $('#msg').value = ''; ask(m); } };
 
  /* ---------- Calendar ---------- */
  function renderCal() {
    $('#cal-title').textContent = cur.toLocaleDateString([], { month: 'long', year: 'numeric' });
    const by = {}, add = (d, t, c) => (by[d] = by[d] || []).push({ t, c });
    T().events.forEach(e => add(e.date, e.title, cIdx(e.course))); T().tasks.forEach(k => k.due && add(k.due, 'Due: ' + k.title, cIdx(k.course)));
    const start = new Date(cur); start.setDate(1 - cur.getDay()); let h = 'Su Mo Tu We Th Fr Sa'.split(' ').map(d => '<div class="dow">' + d + '</div>').join('');
    for (let i = 0; i < 42; i++) {
      const d = new Date(start); d.setDate(start.getDate() + i); const k = iso(d), L = by[k] || [];
      h += '<div class="day' + (d.getMonth() !== cur.getMonth() ? ' out' : '') + (k === iso(new Date()) ? ' now' : '') + '"><b>' + d.getDate() + '</b>' +
        L.slice(0, 2).map(x => '<div class="chip" style="--k:var(--c' + x.c + ')" title="' + esc(x.t) + '">' + esc(x.t) + '</div>').join('') + (L.length > 2 ? '<div class="more">+' + (L.length - 2) + ' more</div>' : '') + '</div>';
    }
    $('#grid').innerHTML = h;
  }
  $('#prev').onclick = () => { cur.setMonth(cur.getMonth() - 1); renderCal(); };
  $('#next').onclick = () => { cur.setMonth(cur.getMonth() + 1); renderCal(); };
  $('#btn-syl').onclick = () => $('#syl').click();
  $('#syl').onchange = async e => {
    const f = e.target.files[0]; if (!f) return; const c = course(f.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ')); let n = 0;
    T().syllabi.push({ name: f.name, course: c.id });
    if (/\.(txt|csv|md)$/i.test(f.name)) (await f.text()).split(/\r?\n/).forEach(l => { const m = l.match(/(\d{4}-\d{2}-\d{2})\W+(.+)/); if (m) { T().events.push({ id: uid(), date: m[1], title: m[2].trim().slice(0, 80), course: c.id }); n++; } });
    save(); e.target.value = ''; render();
    toast(n ? 'Added ' + n + ' dates to ' + c.name : f.name + ' saved. Reading PDFs and Word files comes with the backend.');
  };
 
  /* ---------- Tasks ---------- */
  const DIFF = ['', 'Easy', 'Medium', 'Hard'];
  function taskHtml(k) {
    const soon = !k.done && k.diff === 3 && k.progress < 50 && k.due && (new Date(k.due + 'T00:00') - Date.now()) < 3 * 864e5;
    return '<div class="task' + (k.done ? ' done' : '') + '" style="--k:var(--c' + cIdx(k.course) + ')"><input type="checkbox" data-done="' + k.id + '"' + (k.done ? ' checked' : '') + ' aria-label="Mark done">' +
      '<div><b>' + esc(k.title) + '</b><small>' + esc(cName(k.course)) + (k.due ? ' · Due ' + nice(k.due) : '') + '</small>' +
      '<div class="meta"><span class="diff d' + k.diff + '">' + '●'.repeat(k.diff) + '○'.repeat(3 - k.diff) + ' ' + DIFF[k.diff] + '</span><span>~' + k.min + ' min</span>' + (soon ? '<span class="flag">Start early</span>' : '') + '</div>' +
      '<div class="prog"><input type="range" min="0" max="100" step="25" value="' + k.progress + '" data-prog="' + k.id + '" aria-label="Progress"><span>' + k.progress + '%</span></div></div>' +
      '<button class="ib" data-del="' + k.id + '" aria-label="Delete task">🗑</button></div>';
  }
  function renderTasks() {
    const t = T().tasks, today = iso(new Date()), wk = iso(new Date(Date.now() + 7 * 864e5)), G = { 'Overdue': [], 'Today': [], 'This week': [], 'Later': [], 'Done': [] };
    t.slice().sort((a, b) => (a.due || '9') < (b.due || '9') ? -1 : 1).forEach(k => G[k.done ? 'Done' : !k.due ? 'Later' : k.due < today ? 'Overdue' : k.due === today ? 'Today' : k.due <= wk ? 'This week' : 'Later'].push(k));
    $('#tasks').innerHTML = t.length ? Object.keys(G).filter(g => G[g].length).map(g => '<div class="tgroup">' + g + '</div>' + G[g].map(taskHtml).join('')).join('')
      : '<div class="card empty">No tasks in this term yet.<br>Add one, or upload a syllabus from the Calendar.</div>';
  }
  $('#tasks').onchange = e => {
    const d = e.target.dataset, k = d.done || d.prog ? T().tasks.find(x => x.id === (d.done || d.prog)) : null; if (!k) return;
    if (d.done) { k.done = e.target.checked; if (k.done) k.progress = 100; } else { k.progress = +e.target.value; k.done = k.progress === 100; }
    save(); renderTasks();
  };
  $('#tasks').onclick = e => { const b = e.target.closest('[data-del]'); if (b) { T().tasks = T().tasks.filter(x => x.id !== b.dataset.del); save(); renderTasks(); } };
  const tdlg = $('#tdlg');
  $('#btn-task').onclick = () => { $('#clist').innerHTML = T().courses.map(c => '<option value="' + esc(c.name) + '">').join(''); tdlg.querySelector('form').reset(); tdlg.showModal(); };
  tdlg.addEventListener('close', () => {
    if (tdlg.returnValue !== 'save') return; const f = tdlg.querySelector('form').elements;
    T().tasks.push({ id: uid(), title: f.title.value.trim(), course: course(f.course.value).id, due: f.due.value, diff: +f.diff.value, min: +f.min.value || 45, progress: 0, done: false });
    save(); render(); toast('Task added');
  });
 
  /* ---------- boot / render ---------- */
  function render() {
    const name = (store('sf-users') || {})[me].name, h = new Date().getHours();
    $('#greet').textContent = (h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening') + ', ' + name;
    $('#who').textContent = name; renderTerms();
    if (view === 'cal') renderCal(); if (view === 'tasks') renderTasks();
  }
  function boot() {
    me = store('sf-session'); $('#auth').hidden = !!me; $('#app').hidden = !me;
    if (!me) { setMode('in'); return; }
    load(); $('#log').innerHTML = ''; say('Hi! I can build a study plan, tell you what is due, or re-plan your week.'); go('home');
  }
  boot();
})();