/* Calendar editing: recurring commitments, imported events, and task deadlines. */
(function () {
  const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const $ = s => document.querySelector(s);
  function init({getTerm, save, refresh, notify}) {
    const dialog = document.createElement('dialog');
    dialog.id = 'calendar-editor';
    dialog.setAttribute('aria-labelledby', 'ce-heading');
    dialog.innerHTML = `<form id="ce-form">
      <span class="availability-eyebrow">MAKE YOUR WEEK WORK</span>
      <h2 id="ce-heading">Edit calendar event</h2>
      <p id="ce-context" class="ce-context"></p>
      <label>Title<input id="ce-title" required maxlength="120"></label>
      <label id="ce-scope-field">Apply changes to<select id="ce-scope"><option value="one">Only this occurrence</option><option value="all">Entire weekly commitment</option></select></label>
      <div id="ce-repeat" hidden><fieldset><legend>Repeat on</legend><div class="ce-weekdays">${DAYS.map(d=>`<label><input type="checkbox" value="${d}">${d}</label>`).join('')}</div></fieldset></div>
      <label id="ce-date-field">Date<input id="ce-date" type="date" required></label>
      <div id="ce-time-fields" class="two"><label>Start time<input id="ce-start" type="time" required></label><label>End time<input id="ce-end" type="time" required></label></div>
      <p id="ce-error" class="err" role="alert"></p>
      <p id="ce-removal-note" class="ce-context"></p>
      <div class="ce-actions"><button type="button" id="ce-remove" class="btn ce-danger">Remove</button><button type="button" id="ce-cancel" class="btn">Cancel</button><button class="btn pri" type="submit">Save changes</button></div>
    </form>`;
    document.body.append(dialog);
    let current = null;
    const form = $('#ce-form');
    function scope() {
      const recurring = current.kind === 'block';
      const all = recurring && $('#ce-scope').value === 'all';
      $('#ce-repeat').hidden = !all;
      $('#ce-date-field').hidden = all;
      $('#ce-date').disabled = all;
      $('#ce-title').disabled = recurring && !all;
      $('#ce-removal-note').textContent = current.kind === 'task'
        ? 'Removing this deadline keeps the assignment in Tasks.'
        : all ? 'Changes or removal apply to the whole recurring commitment.'
        : recurring ? 'Changes or removal affect only this occurrence. Other weeks stay the same.' : '';
    }
    $('#ce-scope').onchange = scope;
    $('#ce-cancel').onclick = () => dialog.close();
    $('#grid').addEventListener('click', event => {
      const button = event.target.closest('[data-cal-kind]');
      if (!button) return;
      const {calKind:kind, calId:id, calDate:date} = button.dataset;
      const data = getTerm();
      const item = (kind === 'block' ? Availability.getBlocks() : kind === 'task' ? data.tasks : data.events).find(x=>x.id===id);
      if (!item) return;
      current = {kind, id, date, item};
      form.reset();
      $('#ce-error').textContent = '';
      $('#ce-heading').textContent = kind === 'task' ? 'Edit assignment deadline' : 'Edit calendar event';
      $('#ce-context').textContent = kind === 'block' ? 'A recurring weekly commitment' : kind === 'task' ? 'Keep your assignment and calendar in sync.' : 'An event from your syllabus';
      $('#ce-title').value = item.name || item.title;
      $('#ce-scope-field').hidden = kind !== 'block';
      $('#ce-time-fields').hidden = kind !== 'block';
      $('#ce-start').disabled = $('#ce-end').disabled = kind !== 'block';
      const exception = (item.exceptions || []).find(x=>x.originalDate===date);
      $('#ce-date').value = exception?.date || date;
      $('#ce-start').value = exception?.start || item.start || '09:00';
      $('#ce-end').value = exception?.end || item.end || '10:00';
      document.querySelectorAll('.ce-weekdays input').forEach(input=>input.checked=(item.days||[]).includes(input.value));
      scope();
      dialog.showModal();
    });
    function commit(remove) {
      const {kind,id,date} = current;
      const data = getTerm();
      const all = kind === 'block' && $('#ce-scope').value === 'all';
      if (!remove && !form.reportValidity()) return;
      const title = $('#ce-title').value.trim();
      const selected = [...document.querySelectorAll('.ce-weekdays input:checked')].map(x=>x.value);
      if (!remove && (!title || (all && !selected.length))) {
        $('#ce-error').textContent = !title ? 'Please enter a title.' : 'Choose at least one weekday.'; return;
      }
      if (!remove && kind === 'block' && $('#ce-start').value >= $('#ce-end').value) {
        $('#ce-error').textContent = 'End time must be later than start time.'; return;
      }
      try {
        if (kind === 'block') {
          if (all && remove) Availability.deleteBlock(id);
          else if (all) Availability.updateBlock(id,{name:title,days:selected,start:$('#ce-start').value,end:$('#ce-end').value});
          else {
            const block = Availability.getBlocks().find(x=>x.id===id);
            const exceptions = (block.exceptions||[]).filter(x=>x.originalDate!==date);
            exceptions.push({originalDate:date,date:remove?null:$('#ce-date').value,start:$('#ce-start').value,end:$('#ce-end').value});
            Availability.updateBlock(id,{exceptions});
          }
          data.availabilityBlocks = Availability.getBlocks();
          AvailabilityUI.render();
        } else if (kind === 'task') {
          const task = data.tasks.find(x=>x.id===id);
          if (remove) task.due = '';
          else { task.title=title; task.due=$('#ce-date').value; }
        } else if (remove) data.events = data.events.filter(x=>x.id!==id);
        else {
          const item=data.events.find(x=>x.id===id);
          item.title=title; item.date=$('#ce-date').value;
        }
        save(); dialog.close(); refresh(); notify(remove?'Removed from calendar':'Calendar updated');
      } catch(error) { $('#ce-error').textContent = error.message; }
    }
    form.onsubmit = event => {event.preventDefault();commit(false);};
    $('#ce-remove').onclick = () => commit(true);
  }
  window.CalendarEditor = {init};
})();


/* StudyFlow — Main Application */

(() => {
  const $ = s => document.querySelector(s);
  const uid = () => Math.random().toString(36).slice(2, 9);
  const esc = s => String(s).replace(/[&<>"]/g,
    c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const iso = d => d.getFullYear() + '-' +
    String(d.getMonth()+1).padStart(2,'0') + '-' +
    String(d.getDate()).padStart(2,'0');
  const nice = s => new Date(s+'T00:00').toLocaleDateString(
    [], {weekday:'short',month:'short',day:'numeric'});

  const store = (k,v) => v === undefined
    ? JSON.parse(localStorage.getItem(k) || 'null')
    : localStorage.setItem(k,JSON.stringify(v));

  const toast = m => {
    const t = $('#toast');
    t.textContent = m;
    t.classList.add('on');
    setTimeout(() => t.classList.remove('on'),2600);
  };

  let mode = 'in', me = null, D = null;
  let view = 'home', cur = new Date();
  cur.setDate(1);

  /* ---------- Authentication ---------- */
  // Local prototype only — not production authentication.

  const sha = async s => crypto.subtle
    ? [...new Uint8Array(await crypto.subtle.digest(
        'SHA-256',new TextEncoder().encode(s)
      ))].map(b=>b.toString(16).padStart(2,'0')).join('')
    : btoa(s);

  function setMode(m) {
    mode = m;
    $('#name-row').hidden = m === 'in';
    $('#auth-err').textContent = '';
    $('#auth-sub').textContent = m === 'in'
      ? 'Welcome back. Sign in to continue.'
      : 'Create your account to get started.';
    $('#auth-go').textContent = m === 'in'
      ? 'Sign in' : 'Create account';
    $('#auth-switch').textContent = m === 'in'
      ? 'New here? Create an account'
      : 'Already have an account? Sign in';
  }

  $('#auth-switch').onclick =
    () => setMode(mode === 'in' ? 'up' : 'in');

  $('#auth-form').onsubmit = async e => {
    e.preventDefault();
    const f = e.target.elements;
    const email = f.email.value.trim().toLowerCase();
    const h = await sha(f.pw.value);
    const U = store('sf-users') || {};

    if (mode === 'up') {
      if (U[email]) {
        $('#auth-err').textContent = 'Account already exists.';
        return;
      }
      U[email] = {
        name:f.name.value.trim() || email.split('@')[0],h
      };
      store('sf-users',U);
    } else if (!U[email] || U[email].h !== h) {
      $('#auth-err').textContent = 'Incorrect email or password.';
      return;
    }

    store('sf-session',email);
    e.target.reset();
    boot();
  };

  $('#out').onclick = () => {
    localStorage.removeItem('sf-session');
    boot();
  };

  /* ---------- Data ---------- */

  const save = () => store('sf-data-' + me,D);
  const T = () => D.by[D.term];

  const blank = () => ({
    courses:[],
    tasks:[],
    events:[],
    syllabi:[],
    availabilityBlocks:[],
    studySessions:[]
  });

  function load() {
    D = store('sf-data-' + me);

    if (!D) {
      const id = uid();
      D = {
        terms:[{id,name:'Term 1 · '+new Date().getFullYear()}],
        term:id,
        by:{[id]:blank()}
      };
    }

    Object.values(D.by).forEach(t => {
      t.availabilityBlocks ??= [];
      t.studySessions ??= [];
    });

    save();
  }

  const cIdx = id =>
    Math.max(0,T().courses.findIndex(c=>c.id===id))%6+1;

  const cName = id =>
    T().courses.find(c=>c.id===id)?.name || 'General';

  function course(name) {
    name = (name||'').trim() || 'General';
    let c = T().courses.find(
      x=>x.name.toLowerCase()===name.toLowerCase()
    );
    if (!c) {
      c = {id:uid(),name};
      T().courses.push(c);
    }
    return c;
  }

  function renderTerms() {
    $('#term').innerHTML = D.terms.map(t =>
      `<option value="${t.id}" ${t.id===D.term?'selected':''}>
        ${esc(t.name)}
      </option>`
    ).join('') + '<option value="__new">＋ New term…</option>';
  }

  $('#term').onchange = e => {
    if (e.target.value === '__new') {
      const name = (prompt('New term name:')||'').trim();
      if (name) {
        const id = uid();
        D.terms.push({id,name});
        D.by[id] = blank();
        D.term = id;
      }
    } else {
      D.term = e.target.value;
    }

    Availability.setBlocks(T().availabilityBlocks);
    save();
    render();
  };

  /* ---------- Availability Integration ---------- */

  const nav = document.createElement('button');
  nav.className = 'nav';
  nav.dataset.view = 'availability';
  nav.type = 'button';
  nav.innerHTML = '<span>◷</span>Availability';

  document.querySelector('.nav[data-view="tasks"]').after(nav);

  // Called whenever a commitment is added or removed.
  AvailabilityUI.init(() => {
    T().availabilityBlocks = Availability.getBlocks();
    save();
    toast('Availability updated');
    if (view === 'cal') renderCal();
  });

  /* ---------- Navigation ---------- */

  function go(v) {
    view = v;
    ['home','cal','tasks','availability'].forEach(x => {
      $('#v-'+x).hidden = x !== v;
    });
    document.querySelectorAll('.nav').forEach(b =>
      b.classList.toggle('on',b.dataset.view===v)
    );
    render();
  }

  document.querySelectorAll('.nav').forEach(b => {
    b.onclick = () => go(b.dataset.view);
  });

  /* ---------- Chat ---------- */

  function say(t,who='') {
    const log = $('#log');
    log.insertAdjacentHTML('beforeend',
      `<div class="msg ${who}">${esc(t)}</div>`);
    log.scrollTop = log.scrollHeight;
  }

  function bot(q) {
    const open = T().tasks.filter(k=>!k.done);
    const s = q.toLowerCase();

    if (/plan|study|schedule|adjust|move|resched/.test(s)) {
      if (!open.length)
        return 'Add tasks first to generate a study plan.';

      const last = open.map(k=>k.due).filter(Boolean)
        .sort().pop() || iso(new Date(Date.now()+7*864e5));

      const subs = T().courses.map(c => ({
        id:c.id,
        name:c.name,
        topics:open.filter(k=>k.course===c.id).map(k=>({
          id:k.id,
          name:k.title,
          minutes:Math.max(5,Math.round(
            k.min*(1-k.progress/100)
          ))
        }))
      })).filter(x=>x.topics.length);

      const P = Scheduler.plan({
        exam:last+'T23:00',
        sleep:'23:00',
        wake:'07:00',
        session:50,
        maxHours:4
      },subs);

      if (!P.sessions.length)
        return P.note || 'No study time available.';

      const fmt = d => d.toLocaleTimeString([],{
        hour:'numeric',minute:'2-digit'
      });

      return 'Suggested study sessions:\n' +
        P.sessions.slice(0,4).map(x =>
          '• '+nice(iso(x.start))+' '+fmt(x.start)+
          '–'+fmt(x.end)+': '+
          x.items.map(i=>i.label).join(', ')
        ).join('\n') + (P.note?'\n'+P.note:'');
    }

    if (/due|week|soon|upcoming|homework|task/.test(s)) {
      return open.length
        ? 'Coming up:\n'+open.sort((a,b)=>
            (a.due||'9').localeCompare(b.due||'9')
          ).slice(0,5).map(k =>
            '• '+k.title+' ('+cName(k.course)+')'+
            (k.due?' · '+nice(k.due):'')
          ).join('\n')
        : 'Nothing pending!';
    }

    return 'I can list deadlines or suggest a study plan.';
  }

  $('#chips').innerHTML = [
    'Make me a study plan',
    'What is due soon?',
    'Adjust my schedule'
  ].map(x=>`<button type="button">${x}</button>`).join('');

  const ask = q => {say(q,'me');say(bot(q));};

  $('#chips').onclick = e => {
    if (e.target.tagName==='BUTTON')
      ask(e.target.textContent);
  };

  $('#chat-form').onsubmit = e => {
    e.preventDefault();
    const m = $('#msg').value.trim();
    if (m) {
      $('#msg').value = '';
      ask(m);
    }
  };

  /* ---------- Calendar ---------- */

  CalendarEditor.init({getTerm:T, save, refresh:renderCal, notify:toast});

  function renderCal() {
    $('#cal-title').textContent =
      cur.toLocaleDateString([],{month:'long',year:'numeric'});

    const by = {};
    const add = (date,title,color,kind,id,sourceDate=date) => {
      (by[date]??=[]).push({title,color,kind,id,sourceDate});
    };

    T().events.forEach(e =>
      add(e.date,e.title,cIdx(e.course),'event',e.id)
    );

    T().tasks.forEach(k => {
      if (k.due)
        add(k.due,'Due: '+k.title,cIdx(k.course),'task',k.id);
    });

    // Add recurring unavailable blocks.
    const rangeStart = new Date(
      cur.getFullYear(),cur.getMonth(),1
    );
    const rangeEnd = new Date(
      cur.getFullYear(),cur.getMonth()+1,1
    );

    Availability.getBlockedIntervals(
      rangeStart,rangeEnd
    ).forEach(b => {
      add(
        iso(b.start),
        'Busy: '+b.name+' ('+
          b.start.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})+
          '–'+
          b.end.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})+
          ')',
        4, 'block', b.id, b.originalDate || iso(b.start)
      );
    });

    const start = new Date(cur);
    start.setDate(1-cur.getDay());

    let html = 'Su Mo Tu We Th Fr Sa'.split(' ')
      .map(d=>`<div class="dow">${d}</div>`).join('');

    for (let i=0;i<42;i++) {
      const d = new Date(start);
      d.setDate(start.getDate()+i);
      const key = iso(d);
      const items = by[key]||[];

      html += `<div class="day
        ${d.getMonth()!==cur.getMonth()?'out':''}
        ${key===iso(new Date())?'now':''}">
        <b>${d.getDate()}</b>
        ${items.map(x=>
          `<button type="button" class="chip calendar-event"
            data-cal-kind="${x.kind}" data-cal-id="${esc(x.id)}" data-cal-date="${esc(x.sourceDate)}"
            style="--k:var(--c${x.color})"
            title="${esc(x.title)}">
            ${esc(x.title)}
          </button>`
        ).join('')}
      </div>`;
    }

    $('#grid').innerHTML = html;
  }

  $('#prev').onclick = () => {
    cur.setMonth(cur.getMonth()-1);
    renderCal();
  };

  $('#next').onclick = () => {
    cur.setMonth(cur.getMonth()+1);
    renderCal();
  };

  /* ---------- Syllabus Upload ---------- */

  $('#btn-syl').onclick = () => $('#syl').click();

  $('#syl').onchange = async e => {
    const f = e.target.files[0];
    if (!f) return;

    const c = course(
      f.name.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ')
    );
    let n = 0;

    T().syllabi.push({name:f.name,course:c.id});

    if (/\.(txt|csv|md)$/i.test(f.name)) {
      (await f.text()).split(/\r?\n/).forEach(line => {
        const m = line.match(/(\d{4}-\d{2}-\d{2})\W+(.+)/);
        if (m) {
          T().events.push({
            id:uid(),
            date:m[1],
            title:m[2].trim().slice(0,80),
            course:c.id
          });
          n++;
        }
      });
    }

    save();
    e.target.value = '';
    render();
    toast(n?'Added '+n+' dates':'File recorded');
  };

  /* ---------- Tasks ---------- */

  const DIFF = ['','Easy','Medium','Hard'];

  function taskHtml(k) {
    const soon = !k.done && k.diff===3 &&
      k.progress<50 && k.due &&
      new Date(k.due+'T00:00')-Date.now()<3*864e5;

    return `<div class="task ${k.done?'done':''}"
      style="--k:var(--c${cIdx(k.course)})">
      <input type="checkbox" data-done="${k.id}"
        ${k.done?'checked':''} aria-label="Mark done">
      <div>
        <b>${esc(k.title)}</b>
        <small>${esc(cName(k.course))}
          ${k.due?' · Due '+nice(k.due):''}</small>
        <div class="meta">
          <span class="diff d${k.diff}">
            ${'●'.repeat(k.diff)}${'○'.repeat(3-k.diff)}
            ${DIFF[k.diff]}
          </span>
          <span>~${k.min} min</span>
          ${soon?'<span class="flag">Start early</span>':''}
        </div>
        <div class="prog">
          <input type="range" min="0" max="100"
            step="25" value="${k.progress}"
            data-prog="${k.id}" aria-label="Progress">
          <span>${k.progress}%</span>
        </div>
      </div>
      <button class="ib" data-del="${k.id}"
        aria-label="Delete task">🗑</button>
    </div>`;
  }

  function renderTasks() {
    const today = iso(new Date());
    const wk = iso(new Date(Date.now()+7*864e5));
    const groups = {
      Overdue:[],Today:[],'This week':[],Later:[],Done:[]
    };

    T().tasks.slice().sort((a,b)=>
      (a.due||'9').localeCompare(b.due||'9')
    ).forEach(k => {
      const group = k.done?'Done':
        !k.due?'Later':
        k.due<today?'Overdue':
        k.due===today?'Today':
        k.due<=wk?'This week':'Later';
      groups[group].push(k);
    });

    $('#tasks').innerHTML = T().tasks.length
      ? Object.keys(groups).filter(g=>groups[g].length)
        .map(g=>'<div class="tgroup">'+g+'</div>'+
          groups[g].map(taskHtml).join('')
        ).join('')
      : '<div class="card empty">No tasks yet.</div>';
  }

  $('#tasks').onchange = e => {
    const d = e.target.dataset;
    const id = d.done||d.prog;
    const k = T().tasks.find(x=>x.id===id);
    if (!k) return;

    if (d.done) {
      k.done = e.target.checked;
      k.progress = k.done?100:k.progress===100?0:k.progress;
    } else {
      k.progress = +e.target.value;
      k.done = k.progress===100;
    }

    save();
    renderTasks();
  };

  $('#tasks').onclick = e => {
    const btn = e.target.closest('[data-del]');
    if (!btn) return;
    T().tasks = T().tasks.filter(x=>x.id!==btn.dataset.del);
    save();
    renderTasks();
  };

  const tdlg = $('#tdlg');

  $('#btn-task').onclick = () => {
    $('#clist').innerHTML = T().courses.map(c =>
      `<option value="${esc(c.name)}">`
    ).join('');
    tdlg.querySelector('form').reset();
    tdlg.showModal();
  };

  tdlg.addEventListener('close',()=>{
    if (tdlg.returnValue!=='save') return;

    const f = tdlg.querySelector('form').elements;
    T().tasks.push({
      id:uid(),
      title:f.title.value.trim(),
      course:course(f.course.value).id,
      due:f.due.value,
      diff:+f.diff.value,
      min:+f.min.value||45,
      progress:0,
      done:false
    });

    save();
    render();
    toast('Task added');
  });

  /* ---------- Render & Startup ---------- */

  function render() {
    const name = (store('sf-users')||{})[me]?.name||'Student';
    const h = new Date().getHours();

    $('#greet').textContent =
      (h<12?'Good morning':h<18?'Good afternoon':'Good evening')
      +', '+name;

    $('#who').textContent = name;
    renderTerms();

    if (view==='cal') renderCal();
    if (view==='tasks') renderTasks();
    if (view==='availability') AvailabilityUI.render();
  }

  function boot() {
    me = store('sf-session');
    $('#auth').hidden = !!me;
    $('#app').hidden = !me;

    if (!me) {
      setMode('in');
      return;
    }

    load();
    Availability.setBlocks(T().availabilityBlocks);

    $('#log').innerHTML = '';
    say('Hi! I can build a study plan, tell you what is due, or re-plan your week.');

    go('home');
  }

  boot();
})();

